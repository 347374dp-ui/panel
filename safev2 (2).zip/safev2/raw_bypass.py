import os
import sys
from mitmproxy import http
import json
import copy

# Get the safev2 directory (current file's directory)
SAFEV2_DIR = os.path.dirname(os.path.abspath(__file__))
# Get the parent directory (for fallback if LoginRes_pb2 not in safev2)
PARENT_DIR = os.path.dirname(SAFEV2_DIR)

# Add safev2 directory first (standalone mode)
sys.path.insert(0, SAFEV2_DIR)
# Add parent directory as fallback (for compatibility)
sys.path.insert(1, PARENT_DIR)

# Import crypto and protocols modules (matching safe bypass structure)
try:
    from crypto.encryption_utils import aes_decrypt, encrypt_api
    from protocols.protobuf_utils import get_available_room, CrEaTe_ProTo
    CRYPTO_AVAILABLE = True
except ImportError:
    # Fallback imports
    try:
        from safev2.crypto.encryption_utils import aes_decrypt, encrypt_api
        from safev2.protocols.protobuf_utils import get_available_room, CrEaTe_ProTo
        CRYPTO_AVAILABLE = True
    except ImportError:
        CRYPTO_AVAILABLE = False
        print("[WARNING] crypto/protocols modules not available")

# Always define AESUtils for fallback
import base64
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding

# Import LoginRes_pb2 - try safev2 first (standalone), then parent (compatibility)
try:
    import LoginRes_pb2
except ImportError:
    # If not in safev2, try parent directory
    try:
        sys.path.insert(0, PARENT_DIR)
        import LoginRes_pb2
        print("[INFO] Using LoginRes_pb2 from parent directory")
    except ImportError:
        print("[WARNING] LoginRes_pb2 not found! Fallback method will not work.")
        LoginRes_pb2 = None

class AESUtils:
    key_base64 = "WWcmdGMlREV1aDYlWmNeOA=="
    iv_base64 = "Nm95WkRyMjJFM3ljaGpNJQ=="
    
    @staticmethod
    def decrypt_aes_cbc(cipher_hex):
        key = base64.b64decode(AESUtils.key_base64)
        iv = base64.b64decode(AESUtils.iv_base64)
        ciphertext = bytes.fromhex(cipher_hex)
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        decryptor = cipher.decryptor()
        decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()
        unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
        return unpadder.update(decrypted_data) + unpadder.finalize()
    
    @staticmethod
    def encrypt_aes_cbc(plaintext):
        key = base64.b64decode(AESUtils.key_base64)
        iv = base64.b64decode(AESUtils.iv_base64)
        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(plaintext) + padder.finalize()
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        encryptor = cipher.encryptor()
        return encryptor.update(padded_data) + encryptor.finalize()

# MOBILE_PROTO template (UPDATED 2026-02-15 - Samsung Galaxy S22 Ultra)
MOBILE_PROTO = "aaf8a186a5c94b33453a39cc44d8fdef5971fedbd4ddafda01d8705a9c3628ff9b8ce321f6ffe3bd3afa811c99d7728b3520774ba3b4c8cb35c3e2ce71a5e35f6602a2b6079f01543bc7d2322038d465fe9a6b9dcc0e38a97c278af69574958e99bf413bf59f23f256470d633037a7058d093166a7e28587056f1bdf4a68b52474f46bb66a69b403d47a0b919751402fa47f3f9390eaeefd3725547eec0ffd5b83a4fb3c818725fc36e1f9a803704cc15cf7666011f2233e6eb1a0afc040c47001786315134f484b52e5b80eac1f09c9143f7364b8243eb875a37aac7c391678452d271517278a9ddc45df7cb8e896b061e9cdbc2c81a65f8a4ac9f25f5dee26ce4050b6351b5fd66fb9f1907284779045b6cc39786cb2dfda7df02ce2d7d79cd5e0fdc945aa77b50aa49d87286282a1fcf43477d9f04e77b56965f3b22bbd116fcca91cfa8a85492f9e7d0d941dce936a4baee632cdde59c0e6b85ea6467aeb5aab152f095273d14f86b2f89b3b2b4adede409172c68d1bb4db3955bbed1826e52184c889d58e853922f8f85b3ff124a537b6f29547aabbf4e7ad8121e7a49aa4fe342d790330db28ef637423b05978c5491dfb45e6b72fabc55b116b042820a45eddecc4dc70db664ac42de9e18271f01a0e5b4e80112daa6732372cb66771b5b041dcc05e9dafeda1a99ece355f6b84f6cecc462510da9459353d7cc410e7cf92872a83b54ddfd52aa610f6f2a8060fd2af5848969d66e5f451ad4c622224da8ded151b270321c982a07864ebb33ce2801f914b60c92e9c069f08cd6a6098f72e8afed0f80fff0542863d13716e0aaed7fdccb6e893bfc8572b5723b027ca86faae27312d2e6417d81d54a0ddb8bf2d351306e0501fc4288a3acf3056c7c4fb22303e13ab99f61f14c64249a81c4b6e8c693b74f5e2dd273cf023ad99e220bd78563a56d147b63222af9264d285261d97056bf2926ba66d65886f9b8c1af518c9a97eb8016a5332182035e59dcd303896c7d0f8600936abf663e5d34bb5858373c23cda8352994e674fb4d7e2efa4295e9e40d28e0a786c461e1e7dd42b3f5434311e01f346a32f95c9189e1330a7acf1da60c3cdf173c367183035bda330ab45e9231ecebf883b402b3e103d6105b846d3c579b190dc2478bdb4234a2500cbc084e9d9a1075b0c665c2bd6c2a4c9c2d8d57fcec139a28e3a6134be7b282ce4e3c1ef1f870be238c69740b0aa77a669ffcbea5238beee978dc452824bb394a68e374cee9a2788601dc0aa1db76a31"

# Load template at module level (matching safe bypass exactly)
proto_template = None
if CRYPTO_AVAILABLE:
    try:
        decrypted_bytes = aes_decrypt(MOBILE_PROTO)
        decrypted_hex = decrypted_bytes.hex()
        proto_json = get_available_room(decrypted_hex)
        if proto_json:
            proto_fields = json.loads(proto_json)
            proto_template = copy.deepcopy(proto_fields)
            print(f"[mitmdump] ✅ Template loaded successfully with {len(proto_template)} fields")
        else:
            print("[WARNING] Failed to load template: get_available_room returned None")
            print("[INFO] This usually means protobuf-decoder is not installed.")
            print("[INFO] Install with: pip install protobuf-decoder")
            print("[INFO] Bypass will use fallback method (still works!)")
            proto_template = None
    except Exception as e:
        print(f"[WARNING] Failed to load template: {e}")
        print("[INFO] Bypass will use fallback method (still works!)")
        import traceback
        traceback.print_exc()
        proto_template = None
else:
    print("[WARNING] Template system not available - crypto/protocols modules not found")
    print("[INFO] Bypass will use fallback method (still works!)")

def request(flow: http.HTTPFlow) -> None:
    """Handle request interception - matching safe bypass exactly"""
    if flow.request.method.upper() == "POST" and "/MajorLogin" in flow.request.path:
        try:
            # Use template-based approach if available
            if proto_template and CRYPTO_AVAILABLE:
                request_bytes = flow.request.content
                request_hex = request_bytes.hex()
                decrypted_bytes = aes_decrypt(request_hex)
                decrypted_hex = decrypted_bytes.hex()
                proto_json = get_available_room(decrypted_hex)
                proto_fields = json.loads(proto_json)
                
                uid = None
                access_token = None
                open_id = None
                main_active_platform = None
                client_version = None
                
                # Extract UID from fields 1, 2, 3
                for field_num in ["1", "2", "3"]:
                    if field_num in proto_fields and isinstance(proto_fields[field_num], dict) and "data" in proto_fields[field_num]:
                        potential_uid = str(proto_fields[field_num]["data"])
                        if potential_uid.isdigit() and len(potential_uid) > 5:
                            uid = potential_uid
                            break
                
                # Extract access_token (field 29)
                if "29" in proto_fields and isinstance(proto_fields["29"], dict) and "data" in proto_fields["29"]:
                    access_token = str(proto_fields["29"]["data"])
                
                # Extract open_id (field 22)
                if "22" in proto_fields and isinstance(proto_fields["22"], dict) and "data" in proto_fields["22"]:
                    open_id = str(proto_fields["22"]["data"])
                
                # Extract main_active_platform (field 99 or 100)
                if "99" in proto_fields and isinstance(proto_fields["99"], dict) and "data" in proto_fields["99"]:
                    main_active_platform = str(proto_fields["99"]["data"])
                elif "100" in proto_fields and isinstance(proto_fields["100"], dict) and "data" in proto_fields["100"]:
                    main_active_platform = str(proto_fields["100"]["data"])
                
                # Extract client_version (field 7)
                if "7" in proto_fields and isinstance(proto_fields["7"], dict) and "data" in proto_fields["7"]:
                    client_version = str(proto_fields["7"]["data"])
                
                if access_token and open_id:
                    print(f"{access_token} {open_id}")
                
                # HYBRID APPROACH: Start with template (all required fields), inject real device info
                modified_proto = copy.deepcopy(proto_template)
                
                # List of device-specific fields to preserve from real request
                device_fields = ['8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '24', '25', '26', '41', '42']
                
                # Inject device info from real request
                for field in device_fields:
                    if field in proto_fields and isinstance(proto_fields[field], dict):
                        modified_proto[field] = copy.deepcopy(proto_fields[field])
                
                # Inject credentials from real request
                if access_token and "29" in modified_proto:
                    modified_proto["29"]["data"] = access_token
                if open_id and "22" in modified_proto:
                    modified_proto["22"]["data"] = open_id
                
                # Inject version from real request if present
                if client_version and "7" in modified_proto:
                    modified_proto["7"]["data"] = client_version
                
                # Inject platform from real request if present
                if main_active_platform:
                    if "99" in modified_proto:
                        modified_proto["99"]["data"] = str(main_active_platform)
                    if "100" in modified_proto:
                        modified_proto["100"]["data"] = str(main_active_platform)
                
                # ONLY modify some_flag field (field 5) - this is the bypass
                
                # Set some_flag to 3 for ALL regions (India and Global)
                if "5" in modified_proto and isinstance(modified_proto["5"], dict):
                    modified_proto["5"]["data"] = 2
                else:
                    modified_proto["5"] = {"wire_type": "varint", "data": 2}
                
                is_india = "ind.freefire" in flow.request.host or "IND" in flow.request.path.upper()
                if is_india:
                    print(f"[mitmdump] 🇮🇳 Applied INDIA bypass (some_flag=3)")
                else:
                    print(f"[mitmdump] 🌐 Applied GLOBAL bypass (some_flag=3)")
                
                # Reconstruct protobuf
                proto_bytes = CrEaTe_ProTo(modified_proto)
                hex_data = encrypt_api(proto_bytes)
                flow.request.content = bytes.fromhex(hex_data)
                print(f"[mitmdump] ✅ Request modified successfully! (Length: {len(flow.request.content)} bytes)")
                
            else:
                # Fallback to old method
                print("[mitmdump] Using fallback method (template not available)")
                request_bytes = flow.request.content
                request_hex = request_bytes.hex()
                plaintext = AESUtils.decrypt_aes_cbc(request_hex)
                login_req = LoginRes_pb2.NewLoginReq()
                login_req.ParseFromString(plaintext)
                
                # Check if India bypass
                is_india = "ind.freefire" in flow.request.host or "IND" in flow.request.path.upper()
                if is_india:
                    login_req.some_flag = 3
                    print(f"[mitmdump] 🇮🇳 Applied INDIA bypass (some_flag=3) [FALLBACK MODE]")
                else:
                    login_req.some_flag = 1
                    print(f"[mitmdump] 🌐 Applied GLOBAL bypass (some_flag=1) [FALLBACK MODE]")
                
                modified_bytes = login_req.SerializeToString()
                encrypted = AESUtils.encrypt_aes_cbc(modified_bytes)
                flow.request.content = encrypted
                print(f"[mitmdump] ✅ Request modified successfully! (Length: {len(flow.request.content)} bytes)")
                
        except Exception as e:
            print(f"[mitmdump] ❌ Error modifying request: {e}")
            import traceback
            traceback.print_exc()

def response(flow: http.HTTPFlow) -> None:
    """Response handler - currently disabled"""
    pass

# Additional hooks for monitoring
def client_connected(client):
    print(f"[mitmdump] New client connected: {client.address}")

def client_disconnected(client):
    print(f"[mitmdump] Client disconnected: {client.address}")

def error(flow: http.HTTPFlow):
    if flow.error:
        print(f"[mitmdump] Proxy error: {flow.error}")

# Main function to run the proxy directly
if __name__ == "__main__":
    import subprocess
    import sys
    import os

    # Default port
    port = 24692

    # Check if a different port is specified as command line argument
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print("Invalid port number. Using default port 24692.")
            port = 24692

    # Print startup information
    print("=" * 60)
    print("🚀 RAW BYPASS PROXY SERVER STARTING")
    print("=" * 60)
    print(f"📡 Port: {port}")
    print("🌍 Auto-detection: IND → India bypass | Others → Global bypass")
    if proto_template:
        print(f"✅ Template System: ENABLED ({len(proto_template)} fields loaded)")
    else:
        print("⚠️  Template System: DISABLED (Using fallback method)")
        print("💡 To enable template system: pip install protobuf-decoder")
        print("   (Fallback method still works perfectly!)")
    print("=" * 60)
    print("🔄 Starting proxy server...")
    print()
    
    try:
        # Try different possible mitmdump paths
        mitmdump_paths = [
            "mitmdump",  # System PATH
            "python -m mitmproxy.tools.mitmdump",  # Module execution
            os.path.expanduser("~/.local/bin/mitmdump"),  # Local user install
            "/usr/local/bin/mitmdump",  # Global install
            "python3 -m mitmproxy.tools.mitmdump",  # Python3 module
        ]

        success = False
        for mitmdump_cmd in mitmdump_paths:
            try:
                print(f"🔍 Trying: {mitmdump_cmd}")
                if "python" in mitmdump_cmd:
                    # Split python module command
                    cmd_parts = mitmdump_cmd.split() + ["-s", __file__, "-p", str(port), "--set", "block_global=false"]
                else:
                    cmd_parts = [mitmdump_cmd, "-s", __file__, "-p", str(port), "--set", "block_global=false"]
                
                subprocess.run(cmd_parts, check=True)
                success = True
                break
            except (subprocess.CalledProcessError, FileNotFoundError):
                continue

        if not success:
            print("❌ Could not find mitmdump. Trying alternative approach...")
            print("🔧 Attempting to run as Python module...")

            # Try to import and run mitmproxy directly
            try:
                from mitmproxy.tools import main
                sys.argv = ["mitmdump", "-s", __file__, "-p", str(port), "--set", "block_global=false"]
                main.mitmdump()
            except ImportError:
                print("❌ Error: mitmproxy not properly installed.")
                print("📋 Please install with: pip install mitmproxy")
                print(f"🔄 Or try running manually: python -m mitmproxy.tools.mitmdump -s {__file__} -p {port} --set block_global=false")
            except Exception as e:
                print(f"❌ Error running mitmproxy: {e}")

    except KeyboardInterrupt:
        print("\n🛑 Proxy server stopped by user.")
    except Exception as e:
        print(f"❌ Error starting proxy server: {e}")
        print(f"🔄 Try running manually: python -m mitmproxy.tools.mitmdump -s {__file__} -p {port} --set block_global=false")

if proto_template:
    print("[mitmdump] 🚀 RAW BYPASS MITMProxy script loaded successfully!")
    print(f"[mitmdump] ✅ Template System: Template loaded with {len(proto_template)} fields")
else:
    print("[mitmdump] 🚀 RAW BYPASS MITMProxy script loaded successfully!")
    print("[mitmdump] ⚠️  Template System: Not available (using fallback)")
