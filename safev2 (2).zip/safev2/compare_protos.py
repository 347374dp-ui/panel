"""
Compare old and new protobuf templates to find differences
"""

import sys
sys.path.insert(0, r'f:\src\uid bypass\bypass main\safev2')

from crypto.encryption_utils import aes_decrypt
from protocols.protobuf_utils import get_available_room
import json

# Old template from raw_bypass.py
OLD_PROTO = "6326c9c1859ce2b339f77897132701cf550c24c535eb0c6304eabd1ec0c3b8f48b21909d48d30fc1ddf1b1bd3864fee24b4b36b13585439eb880865c32821aca23a2a8b128b251d8215ae9dba719125708bd480439c49e639d946bc7c50a226f68574ac1b9af2edc357d3f0b5dcf0fa63f5b12f59f18424b6037b36de1200a964eccf5e9569f1b3fa8e832f9b3e65008cafa0a1e4d7f30bb458fa2ce7f60d7823e66468652bf1e789d70fbeb4fe244493faf9b1794779e9104d5542708c3e35d2d99d8a12c2c2732c4002fd464a073ed841528d0f5afde0dab83daf69338d43796633bb0dc075bfb76398878cf561d06b898f8190144bc45c9928706abcfd9c3b6cdabc11429f1c44f985fb7be438f60ca4b59e846a890d8de003789fdc581297b1618ae9d4980bc474032af82fcab135830fbe931a0484d20a308305709790c59e4228801ef730d4c96e517dce0c1ef9036516f9e5642d46c2fe92257af2f1941925983378bd6dd7e2321c466fe72638906b8d7e81e673869e8a945db35b02c2270b26882bd85a5e4c6b882847379a8ef9e7483f284b74dbb337d09c6778b24232d48b3ccb6a5966502c9de5907321fd423dde35436f24b0bace6f82c0f0756cec59cd954255eca6e08023696e639e4347292f785e88e2cb92b20591caccd251da7839dc8340dcf933a5309151e2a0f001652e64fa4cada9ea1feaa31082d5f4bfda58fc5d31dd0864b7c9f5e473cba4d885d3fd90f08c0e06310b864e6cbfcf4a660308785f0ab1418995f6e5391cfa93f3e312afe7e561bfeaad0c7daa3083077027d451a19722832cee0d9ab8303ccc047ce693a1f598b65a0ce0a0cff2414274cb1b787218a1499abe4859a07c5ab303ca3ef687ba072016b438778b351a753c6369e82fb8cd8a82389ba2d96c40b940d3ba511e1b8c8ebad8e19b16d0ef321b9123ea0e140a0e772beeb5cf788d67573bfa0f601082f365c6cc14bb7c28ed92b1138436ac13835d132f03aaa7cb9869e10157251c631b5aa0fa54e49f781fcc28ee0e738c092c68f8f61fd9cfbf17c508a55eaacc73ee502ce0bbdccba22becf34a862e47e943c055f8fd9d46463c13d06a000daf73d94143e9599fee50ee44b4d0efb9c537b13267a05a8e1c0"

# New protos from captured_protos folder
NEW_PROTO_1 = open(r"f:\src\uid bypass\bypass main\safev2\captured_protos\encrypted_proto_global_20260207_153146.txt").read().strip()
NEW_PROTO_2 = open(r"f:\src\uid bypass\bypass main\safev2\captured_protos\encrypted_proto_global_20260207_153206.txt").read().strip()

print("=" * 80)
print("PROTO COMPARISON ANALYSIS")
print("=" * 80)
print()

# Analyze old proto
print("📋 OLD TEMPLATE (from raw_bypass.py)")
print("-" * 80)
dec_old = aes_decrypt(OLD_PROTO)
json_old = get_available_room(dec_old.hex())
struct_old = json.loads(json_old)
print(f"Total fields: {len(struct_old)}")
print(f"Version: {struct_old.get('7', {}).get('data', 'Unknown')}")
print(f"some_flag (field 5): {struct_old.get('5', {}).get('data', 'N/A')}")
print()

# Analyze new proto 1
print("📋 NEW PROTO 1 (captured 20260207_153146)")
print("-" * 80)
dec_new1 = aes_decrypt(NEW_PROTO_1)
json_new1 = get_available_room(dec_new1.hex())
struct_new1 = json.loads(json_new1)
print(f"Total fields: {len(struct_new1)}")
print(f"Version: {struct_new1.get('7', {}).get('data', 'Unknown')}")
print(f"some_flag (field 5): {struct_new1.get('5', {}).get('data', 'N/A')}")
print()

# Analyze new proto 2
print("📋 NEW PROTO 2 (captured 20260207_153206)")
print("-" * 80)
dec_new2 = aes_decrypt(NEW_PROTO_2)
json_new2 = get_available_room(dec_new2.hex())
struct_new2 = json.loads(json_new2)
print(f"Total fields: {len(struct_new2)}")
print(f"Version: {struct_new2.get('7', {}).get('data', 'Unknown')}")
print(f"some_flag (field 5): {struct_new2.get('5', {}).get('data', 'N/A')}")
print()

print("=" * 80)
print("🔍 DETAILED FIELD COMPARISON")
print("=" * 80)
print()

# Find all unique fields
all_fields = set(struct_old.keys()) | set(struct_new1.keys()) | set(struct_new2.keys())
all_fields = sorted([int(f) for f in all_fields])

print("Fields present in:")
old_only = set(struct_old.keys()) - set(struct_new1.keys())
new1_only = set(struct_new1.keys()) - set(struct_old.keys())
new2_only = set(struct_new2.keys()) - set(struct_old.keys())

if old_only:
    print(f"\n❌ OLD ONLY: {sorted([int(f) for f in old_only])}")
if new1_only:
    print(f"✅ NEW1 ONLY: {sorted([int(f) for f in new1_only])}")
if new2_only:
    print(f"✅ NEW2 ONLY: {sorted([int(f) for f in new2_only])}")

print("\n" + "=" * 80)
print("🔑 KEY FIELDS COMPARISON")
print("=" * 80)

key_fields = ['5', '7', '22', '29', '99', '100', '134', '168']

for field in key_fields:
    print(f"\nField {field}:")
    
    old_val = struct_old.get(field, {})
    new1_val = struct_new1.get(field, {})
    new2_val = struct_new2.get(field, {})
    
    if old_val:
        print(f"  OLD:  {old_val.get('wire_type', 'N/A'):10s} = {old_val.get('data', 'N/A')}")
    else:
        print(f"  OLD:  NOT PRESENT")
        
    if new1_val:
        print(f"  NEW1: {new1_val.get('wire_type', 'N/A'):10s} = {new1_val.get('data', 'N/A')}")
    else:
        print(f"  NEW1: NOT PRESENT")
        
    if new2_val:
        print(f"  NEW2: {new2_val.get('wire_type', 'N/A'):10s} = {new2_val.get('data', 'N/A')}")
    else:
        print(f"  NEW2: NOT PRESENT")
    
    # Check if changed
    old_data = old_val.get('data') if old_val else None
    new1_data = new1_val.get('data') if new1_val else None
    new2_data = new2_val.get('data') if new2_val else None
    
    if old_data != new1_data or old_data != new2_data:
        print(f"  ⚠️  VALUES DIFFER!")

# Check for NEW field 168 specifically
print("\n" + "=" * 80)
print("🚨 CRITICAL FINDING: Field 168")
print("=" * 80)

if '168' not in struct_old and '168' in struct_new1:
    print("⚠️  Field 168 is MISSING in old template!")
    print("✅ Field 168 is PRESENT in new captures!")
    print()
    print(f"NEW1 Field 168: {struct_new1.get('168', {})}")
    print(f"NEW2 Field 168: {struct_new2.get('168', {})}")
    print()
    print("💡 THIS IS LIKELY THE PROBLEM!")
    print("   The game might be requiring field 168 now.")
    print("   You need to update your template with one of the new captures.")

print("\n" + "=" * 80)
print("📊 SUMMARY")
print("=" * 80)
print(f"Old template: {len(struct_old)} fields")
print(f"New proto 1:  {len(struct_new1)} fields")
print(f"New proto 2:  {len(struct_new2)} fields")
print(f"Field count difference: {len(struct_new1) - len(struct_old):+d}")
print()
print("✅ RECOMMENDATION:")
print("   1. Run: python update_template.py")
print("   2. Select one of the new captured protos")
print("   3. Restart your bypass proxy")
print("=" * 80)
