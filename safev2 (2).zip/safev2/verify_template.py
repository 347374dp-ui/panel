import sys
sys.path.insert(0, r'f:\src\uid bypass\bypass main\safev2')

from crypto.encryption_utils import aes_decrypt
from protocols.protobuf_utils import get_available_room
import json

# Import directly
from raw_bypass import MOBILE_PROTO

print('=' * 80)
print('TEMPLATE UPDATE VERIFICATION')
print('=' * 80)
print()

dec = aes_decrypt(MOBILE_PROTO)
json_data = get_available_room(dec.hex())
struct = json.loads(json_data)

print(f'Total Fields: {len(struct)}')
print(f'Version: {struct.get("7", {}).get("data", "Unknown")}')
print(f'some_flag: {struct.get("5", {}).get("data", "N/A")}')
print(f'Platform 99: {struct.get("99", {}).get("data", "N/A")}')
print(f'Platform 100: {struct.get("100", {}).get("data", "N/A")}')
print()
print('Key Changes:')
print('  Version: 2.117.5 -> 1.120.17')
print('  Platform: 3 -> 4')
print('  Fields: 53 -> 56')
print()
print('=' * 80)
print('READY TO USE!')
print('Run: python raw_bypass.py')
print('=' * 80)
