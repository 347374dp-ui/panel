"""
AES Encryption/Decryption Utilities
Handles AES-CBC encryption and decryption with PKCS7 padding
"""

import base64

# Try pycryptodome first, fallback to cryptography
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
    USE_CRYPTO = True
except ImportError:
    # Fallback to cryptography library
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives import padding
    USE_CRYPTO = False


# AES Configuration (same as raw_bypass.py)
KEY_BASE64 = "WWcmdGMlREV1aDYlWmNeOA=="
IV_BASE64 = "Nm95WkRyMjJFM3ljaGpNJQ=="


def _get_key_iv():
    """Get AES key and IV from base64 strings"""
    key = base64.b64decode(KEY_BASE64)
    iv = base64.b64decode(IV_BASE64)
    return key, iv


def aes_decrypt(cipher_text):
    """
    Decrypt AES-CBC encrypted data
    
    Args:
        cipher_text: Hex string or bytes of encrypted data
        
    Returns:
        bytes: Decrypted plaintext
    """
    if isinstance(cipher_text, str):
        cipher_bytes = bytes.fromhex(cipher_text)
    else:
        cipher_bytes = bytes(cipher_text)
    
    key, iv = _get_key_iv()
    
    if USE_CRYPTO:
        cipher = AES.new(key, AES.MODE_CBC, iv)
        # Handle padding if needed
        if len(cipher_bytes) % AES.block_size != 0:
            cipher_bytes = pad(cipher_bytes, AES.block_size)
        decrypted = cipher.decrypt(cipher_bytes)
        try:
            return unpad(decrypted, AES.block_size)
        except ValueError:
            return decrypted
    else:
        # Use cryptography library
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        decryptor = cipher.decryptor()
        decrypted_data = decryptor.update(cipher_bytes) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        try:
            return unpadder.update(decrypted_data) + unpadder.finalize()
        except ValueError:
            return decrypted_data


def aes_encrypt(plain_text):
    """
    Encrypt data using AES-CBC
    
    Args:
        plain_text: Bytes or hex string to encrypt
        
    Returns:
        bytes: Encrypted ciphertext
    """
    if isinstance(plain_text, str):
        plain_bytes = bytes.fromhex(plain_text)
    else:
        plain_bytes = bytes(plain_text)
    
    key, iv = _get_key_iv()
    
    if USE_CRYPTO:
        cipher = AES.new(key, AES.MODE_CBC, iv)
        cipher_text = cipher.encrypt(pad(plain_bytes, AES.block_size))
        return cipher_text
    else:
        # Use cryptography library
        backend = default_backend()
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(plain_bytes) + padder.finalize()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        encryptor = cipher.encryptor()
        return encryptor.update(padded_data) + encryptor.finalize()


def encrypt_api(plain_text):
    """
    Encrypt and return as hex string (for compatibility with safe bypass)
    Matches safe bypass encrypt_api() exactly
    
    Args:
        plain_text: Bytes or hex string to encrypt
        
    Returns:
        str: Hex string of encrypted data
    """
    if isinstance(plain_text, (bytes, bytearray)):
        plain_bytes = bytes(plain_text)
    elif isinstance(plain_text, str):
        # Check if it's hex string
        try:
            plain_bytes = bytes.fromhex(plain_text)
        except ValueError:
            # Not hex, treat as regular string
            plain_bytes = plain_text.encode('utf-8')
    else:
        plain_bytes = bytes(plain_text)
    
    encrypted_bytes = aes_encrypt(plain_bytes)
    return encrypted_bytes.hex()

