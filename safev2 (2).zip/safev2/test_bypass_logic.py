"""
Test what the bypass does with the template
"""
import sys
sys.path.insert(0, r'f:\src\uid bypass\bypass main\safev2')

from raw_bypass import MOBILE_PROTO, proto_template
from crypto.encryption_utils import aes_decrypt
from protocols.protobuf_utils import get_available_room
import json
import copy

print("=" * 80)
print("BYPASS LOGIC TEST")
print("=" * 80)
print()

# Show what's in the template
print("📋 TEMPLATE (what we START with):")
print(f"   Field 5 (some_flag): {proto_template.get('5', {}).get('data', 'N/A')}")
print(f"   Field 7 (version): {proto_template.get('7', {}).get('data', 'N/A')}")
print(f"   Field 22 (open_id): {proto_template.get('22', {}).get('data', 'N/A')[:20]}...")
print(f"   Field 29 (access_token): {proto_template.get('29', {}).get('data', 'N/A')[:20]}...")
print(f"   Field 99 (platform): {proto_template.get('99', {}).get('data', 'N/A')} (type: {proto_template.get('99', {}).get('wire_type', 'N/A')})")
print(f"   Field 100 (platform): {proto_template.get('100', {}).get('data', 'N/A')} (type: {proto_template.get('100', {}).get('wire_type', 'N/A')})")
print(f"   Total fields: {len(proto_template)}")
print()

# Simulate what happens during bypass
print("🔄 BYPASS PROCESS:")
print("   1. Copy template")
modified = copy.deepcopy(proto_template)

print("   2. Extract credentials from real request (simulated)")
access_token = "USER_ACCESS_TOKEN_FROM_REAL_REQUEST"
open_id = "USER_OPEN_ID_FROM_REAL_REQUEST"
client_version = "1.120.17"  # From real request
main_active_platform = "4"   # From real request

print(f"      - access_token: {access_token}")
print(f"      - open_id: {open_id}")
print(f"      - client_version: {client_version}")
print(f"      - platform: {main_active_platform}")
print()

print("   3. Inject real user credentials into template copy")
# This is what the code does
if "29" in modified:
    modified["29"]["data"] = access_token
if "22" in modified:
    modified["22"]["data"] = open_id
if client_version:
    if "7" in modified:
        modified["7"]["data"] = client_version
if main_active_platform:
    if "99" in modified:
        if modified["99"].get("wire_type") == "string":
            modified["99"]["data"] = str(main_active_platform)
    if "100" in modified:
        if modified["100"].get("wire_type") == "string":
            modified["100"]["data"] = str(main_active_platform)

print("   4. Keep some_flag = 1 for Global (or set to 3 for India)")
print()

print("📤 FINAL REQUEST (what gets sent to server):")
print(f"   Field 5 (some_flag): {modified.get('5', {}).get('data', 'N/A')} ✅ BYPASS ENABLED")
print(f"   Field 7 (version): {modified.get('7', {}).get('data', 'N/A')} ✅ UP-TO-DATE")
print(f"   Field 22 (open_id): {modified.get('22', {}).get('data', 'N/A')} ✅ REAL USER")
print(f"   Field 29 (access_token): {modified.get('29', {}).get('data', 'N/A')} ✅ REAL USER")
print(f"   Field 99 (platform): {modified.get('99', {}).get('data', 'N/A')} ✅ CORRECT")
print(f"   Field 100 (platform): {modified.get('100', {}).get('data', 'N/A')} ✅ CORRECT")
print(f"   Total fields: {len(modified)} ✅ ALL FIELDS PRESENT")
print()

print("=" * 80)
print("✅ BYPASS SHOULD WORK NOW!")
print("=" * 80)
print()
print("Key points:")
print("  • Template has CORRECT version (1.120.17)")
print("  • Template has CORRECT platform (4)")
print("  • Template has ALL required fields (56)")
print("  • User credentials are INJECTED from real request")
print("  • some_flag is set to 1 (Global) or 3 (India)")
print()
print("What was WRONG before:")
print("  ❌ Old template had version 2.117.5 (outdated)")
print("  ❌ Old template had platform 3 (wrong)")
print("  ❌ Old template had only 53 fields (missing new fields)")
print("  ❌ Code was forcing version to 1.118.12 if not detected")
print()
print("What's FIXED now:")
print("  ✅ Template updated to version 1.120.17")
print("  ✅ Template updated to platform 4")
print("  ✅ Template has 56 fields (all required)")
print("  ✅ Code keeps template version instead of forcing old version")
print("  ✅ Code respects wire_type (string vs int)")
