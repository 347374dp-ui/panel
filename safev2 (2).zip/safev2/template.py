"""
Protobuf Template Handler
Manages the MOBILE_PROTO template for safe field preservation
"""

import copy
import json
import os
import sys

# Handle imports - support both relative and absolute
try:
    from .crypto.encryption_utils import aes_decrypt
    from .protocols.protobuf_utils import parse_protobuf, protobuf_to_json, create_protobuf, get_available_room, CrEaTe_ProTo
except ImportError:
    # Fallback to absolute imports when run as script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
    from crypto.encryption_utils import aes_decrypt
    from protocols.protobuf_utils import parse_protobuf, protobuf_to_json, create_protobuf, get_available_room, CrEaTe_ProTo


# MOBILE_PROTO: Pre-captured, known-good request from a real mobile device
# UPDATED: 2026-02-15 - Samsung Galaxy S22 Ultra
# This serves as a template to ensure all required fields are present
MOBILE_PROTO_HEX = (
    "aaf8a186a5c94b33453a39cc44d8fdef5971fedbd4ddafda01d8705a9c3628ff9b8ce321f6ffe3bd3afa811c99d7728b3520774ba3b4c8cb35c3e2ce71a5e35f6602a2b6079f01543bc7d2322038d465fe9a6b9dcc0e38a97c278af69574958e99bf413bf59f23f256470d633037a7058d093166a7e28587056f1bdf4a68b52474f46bb66a69b403d47a0b919751402fa47f3f9390eaeefd3725547eec0ffd5b83a4fb3c818725fc36e1f9a803704cc15cf7666011f2233e6eb1a0afc040c47001786315134f484b52e5b80eac1f09c9143f7364b8243eb875a37aac7c391678452d271517278a9ddc45df7cb8e896b061e9cdbc2c81a65f8a4ac9f25f5dee26ce4050b6351b5fd66fb9f1907284779045b6cc39786cb2dfda7df02ce2d7d79cd5e0fdc945aa77b50aa49d87286282a1fcf43477d9f04e77b56965f3b22bbd116fcca91cfa8a85492f9e7d0d941dce936a4baee632cdde59c0e6b85ea6467aeb5aab152f095273d14f86b2f89b3b2b4adede409172c68d1bb4db3955bbed1826e52184c889d58e853922f8f85b3ff124a537b6f29547aabbf4e7ad8121e7a49aa4fe342d790330db28ef637423b05978c5491dfb45e6b72fabc55b116b042820a45eddecc4dc70db664ac42de9e18271f01a0e5b4e80112daa6732372cb66771b5b041dcc05e9dafeda1a99ece355f6b84f6cecc462510da9459353d7cc410e7cf92872a83b54ddfd52aa610f6f2a8060fd2af5848969d66e5f451ad4c622224da8ded151b270321c982a07864ebb33ce2801f914b60c92e9c069f08cd6a6098f72e8afed0f80fff0542863d13716e0aaed7fdccb6e893bfc8572b5723b027ca86faae27312d2e6417d81d54a0ddb8bf2d351306e0501fc4288a3acf3056c7c4fb22303e13ab99f61f14c64249a81c4b6e8c693b74f5e2dd273cf023ad99e220bd78563a56d147b63222af9264d285261d97056bf2926ba66d65886f9b8c1af518c9a97eb8016a5332182035e59dcd303896c7d0f8600936abf663e5d34bb5858373c23cda8352994e674fb4d7e2efa4295e9e40d28e0a786c461e1e7dd42b3f5434311e01f346a32f95c9189e1330a7acf1da60c3cdf173c367183035bda330ab45e9231ecebf883b402b3e103d6105b846d3c579b190dc2478bdb4234a2500cbc084e9d9a1075b0c665c2bd6c2a4c9c2d8d57fcec139a28e3a6134be7b282ce4e3c1ef1f870be238c69740b0aa77a669ffcbea5238beee978dc452824bb394a68e374cee9a2788601dc0aa1db76a31"
)


class ProtobufTemplate:
    """
    Manages protobuf template for safe field preservation
    """
    
    def __init__(self):
        """Initialize template from MOBILE_PROTO"""
        self._template = None
        self._load_template()
    
    def _load_template(self):
        """Load and parse the MOBILE_PROTO template"""
        try:
            # Decrypt MOBILE_PROTO
            decrypted_bytes = aes_decrypt(MOBILE_PROTO_HEX)
            
            # Use get_available_room (matching safe bypass exactly)
            decrypted_hex = decrypted_bytes.hex()
            proto_json = get_available_room(decrypted_hex)
            
            if not proto_json:
                raise ValueError("Failed to parse MOBILE_PROTO template")
            
            self._template = json.loads(proto_json)
            
            if not self._template:
                raise ValueError("Failed to parse MOBILE_PROTO template")
            
            print(f"[Template] Loaded template with {len(self._template)} fields")
        except Exception as e:
            print(f"[Template] ERROR: Failed to load template: {e}")
            import traceback
            traceback.print_exc()
            self._template = {}
    
    def get_template(self):
        """
        Get a copy of the template
        
        Returns:
            dict: Copy of the template field dictionary
        """
        if not self._template:
            return {}
        return copy.deepcopy(self._template)
    
    def create_modified_request(self, original_request_bytes, modifications=None):
        """
        Create a modified request using template-based approach
        
        Args:
            original_request_bytes: Original encrypted request bytes
            modifications: Dict of field modifications
                          Format: {field_num: value} or {field_num: {"wire_type": "...", "data": ...}}
        
        Returns:
            bytes: Modified encrypted request, or None on error
        """
        try:
            # Decrypt original request (matching safe bypass exactly)
            request_hex = original_request_bytes.hex() if isinstance(original_request_bytes, bytes) else original_request_bytes
            decrypted_bytes = aes_decrypt(request_hex)
            decrypted_hex = decrypted_bytes.hex()
            
            # Parse original using get_available_room (matching safe bypass)
            proto_json = get_available_room(decrypted_hex)
            if not proto_json:
                print("[Template] Failed to parse original request")
                return None
            
            original_fields = json.loads(proto_json)
            
            # Start with template (ensures all fields are present)
            modified_proto = self.get_template()
            
            if not modified_proto:
                print("[Template] Template not loaded, using original fields only")
                modified_proto = original_fields
            
            # Extract critical fields from original
            critical_fields = {
                "22": "open_id",
                "29": "access_token", 
                "7": "client_version",
                "99": "main_active_platform",
                "100": "main_active_platform_alt"
            }
            
            # Preserve critical fields from original (matching safe bypass exactly)
            # Field 29: access_token
            if "29" in original_fields:
                access_token = str(original_fields["29"].get("data", ""))
                if "29" in modified_proto and isinstance(modified_proto["29"], dict):
                    modified_proto["29"]["data"] = access_token if access_token else modified_proto["29"].get("data", "")
            
            # Field 22: open_id
            if "22" in original_fields:
                open_id = str(original_fields["22"].get("data", ""))
                if "22" in modified_proto and isinstance(modified_proto["22"], dict):
                    modified_proto["22"]["data"] = open_id if open_id else modified_proto["22"].get("data", "")
            
            # Field 7: client_version (matching safe bypass logic)
            client_version = None
            if "7" in original_fields:
                client_version = str(original_fields["7"].get("data", ""))
            
            if client_version:
                if "7" in modified_proto and isinstance(modified_proto["7"], dict):
                    modified_proto["7"]["data"] = client_version
                else:
                    modified_proto["7"] = {"wire_type": "string", "data": client_version}
            else:
                # Set default client_version if not in original request
                if "7" in modified_proto and isinstance(modified_proto["7"], dict):
                    modified_proto["7"]["data"] = "1.118.12"
                else:
                    modified_proto["7"] = {"wire_type": "string", "data": "1.118.12"}
            
            # Fields 99 and 100: main_active_platform (matching safe bypass logic)
            main_active_platform = None
            if "99" in original_fields:
                main_active_platform = str(original_fields["99"].get("data", ""))
            elif "100" in original_fields:
                main_active_platform = str(original_fields["100"].get("data", ""))
            
            if main_active_platform:
                if "99" in modified_proto and isinstance(modified_proto["99"], dict):
                    modified_proto["99"]["data"] = int(main_active_platform)
                else:
                    modified_proto["99"] = {"wire_type": "varint", "data": int(main_active_platform)}
                
                if "100" in modified_proto and isinstance(modified_proto["100"], dict):
                    modified_proto["100"]["data"] = int(main_active_platform)
                else:
                    modified_proto["100"] = {"wire_type": "varint", "data": int(main_active_platform)}
            
            # Apply custom modifications
            if modifications:
                for field_num, value in modifications.items():
                    field_num_str = str(field_num)
                    if field_num_str in modified_proto:
                        if isinstance(value, dict):
                            modified_proto[field_num_str].update(value)
                        else:
                            modified_proto[field_num_str]["data"] = value
                    else:
                        # Add new field
                        if isinstance(value, dict):
                            modified_proto[field_num_str] = value
                        else:
                            modified_proto[field_num_str] = {
                                "wire_type": "string" if isinstance(value, str) else "varint",
                                "data": value
                            }
            
            # Reconstruct protobuf using CrEaTe_ProTo (matching safe bypass)
            proto_bytes = CrEaTe_ProTo(modified_proto)
            
            # Re-encrypt using encrypt_api (matching safe bypass - returns hex)
            try:
                from .crypto.encryption_utils import encrypt_api
            except ImportError:
                from crypto.encryption_utils import encrypt_api
            hex_data = encrypt_api(proto_bytes)
            
            # Convert hex to bytes (matching safe bypass)
            return bytes.fromhex(hex_data)
            
        except Exception as e:
            print(f"[Template] ERROR creating modified request: {e}")
            import traceback
            traceback.print_exc()
            return None


# Global template instance
_template_instance = None


def get_template():
    """Get the global template instance"""
    global _template_instance
    if _template_instance is None:
        _template_instance = ProtobufTemplate()
    return _template_instance

