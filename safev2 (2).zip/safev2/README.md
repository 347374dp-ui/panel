# SafeV2 - Template-Based Protobuf Bypass System

## Overview

SafeV2 provides a **template-based approach** to protobuf modification that preserves all fields, ensuring safer bypass operations. Unlike compiled proto definitions that may lose unknown fields, SafeV2 uses a generic protobuf decoder to preserve the complete structure.

## Why SafeV2?

### The Problem with Compiled Proto Definitions

When using compiled proto definitions (like `LoginRes_pb2.NewLoginReq()`):
- Only fields defined in the proto are preserved
- Unknown fields are silently dropped
- Field loss can cause server-side validation failures

### The SafeV2 Solution

SafeV2 uses a **template-based approach**:
1. **MOBILE_PROTO Template**: Pre-captured, known-good request from a real device
2. **Generic Protobuf Decoder**: Parses protobuf without requiring proto definitions
3. **Field Preservation**: All fields from template are preserved
4. **Selective Modification**: Only modify specific fields (e.g., `some_flag`)

## Structure

```
safev2/
├── __init__.py              # Package initialization
├── README.md                # This file
├── raw_bypass.py            # Main bypass script (mitmproxy addon)
├── template.py              # Template handler (MOBILE_PROTO management)
├── crypto/
│   ├── __init__.py
│   └── encryption_utils.py  # AES encryption/decryption
└── protocols/
    ├── __init__.py
    └── protobuf_utils.py    # Generic protobuf parser/reconstructor
```

**Note**: The root `raw_bypass.py` is a compatibility wrapper that imports from `safev2/raw_bypass.py`

## Installation

```bash
pip install protobuf-decoder pycryptodome
```

## Usage

### Basic Usage

The main bypass script is `safev2/raw_bypass.py`. It can be used directly:

```bash
python -m mitmproxy.tools.mitmdump -s safev2/raw_bypass.py -p 24692
```

Or use the root `raw_bypass.py` (which imports from safev2):

```bash
python -m mitmproxy.tools.mitmdump -s raw_bypass.py -p 24692
```

### Programmatic Usage

```python
from safev2.template import get_template

template = get_template()
modifications = {
    "5": 1  # some_flag = 1
}
modified_request = template.create_modified_request(original_bytes, modifications)
```

### How It Works

1. **Template Loading**: On first use, `MOBILE_PROTO` is decrypted and parsed into a field dictionary
2. **Request Parsing**: Original request is decrypted and parsed using generic decoder
3. **Field Extraction**: Critical fields (22=open_id, 29=access_token, 7=version, etc.) are extracted from original
4. **Template Merge**: Template is used as base, critical fields from original are injected
5. **Modification**: Custom modifications (e.g., `some_flag`) are applied
6. **Reconstruction**: Protobuf is reconstructed from field dictionary
7. **Re-encryption**: Modified protobuf is encrypted and returned

## Key Features

- ✅ **Complete Field Preservation**: All fields from template are preserved
- ✅ **Unknown Field Support**: Handles fields not in proto definitions
- ✅ **Generic Decoder**: No proto definition required for parsing
- ✅ **Backward Compatible**: Falls back to old method if template unavailable
- ✅ **Region Support**: Supports both Global (some_flag=1) and India (some_flag=3) bypasses

## Critical Fields Preserved

The template system specifically preserves these fields from the original request:
- **Field 22**: `open_id`
- **Field 29**: `access_token` (login_token)
- **Field 7**: `client_version`
- **Field 99/100**: `main_active_platform`

All other fields come from the `MOBILE_PROTO` template, ensuring completeness.

## Technical Details

### MOBILE_PROTO

The `MOBILE_PROTO` hex string is a pre-captured, encrypted request from a real mobile device. It serves as a template representing the complete, valid protobuf structure the server expects.

### Generic Protobuf Decoder

Uses `protobuf_decoder` library to parse protobuf at the wire level, preserving all fields regardless of proto definitions.

### Field Dictionary Format

```python
{
    "field_number": {
        "wire_type": "varint" | "string" | "bytes" | "length_delimited",
        "data": <value>
    }
}
```

## Error Handling

SafeV2 includes graceful fallback:
- If `protobuf_decoder` is not installed, falls back to old method
- If template loading fails, falls back to old method
- All errors are logged with clear messages

## Comparison: Old vs SafeV2

| Feature | Old Method | SafeV2 |
|---------|-----------|--------|
| Field Preservation | Only proto-defined fields | All fields |
| Unknown Fields | Lost | Preserved |
| Template-Based | No | Yes |
| Size Match | Often mismatched | Preserved |
| Safety | Medium | High |

## License

Part of the raw_bypass project.

