"""Protocol buffer utilities for generic parsing and reconstruction"""

