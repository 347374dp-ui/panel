"""
Generic Protocol Buffer Utilities
Provides field-level protobuf parsing and reconstruction without requiring proto definitions
"""

import json
import codecs

try:
    from protobuf_decoder.protobuf_decoder import Parser
    PROTOBUF_DECODER_AVAILABLE = True
except ImportError:
    PROTOBUF_DECODER_AVAILABLE = False
    print("[WARNING] protobuf_decoder not available. Install with: pip install protobuf-decoder")


def _encode_varint(value):
    """
    Encode an integer as a varint (variable-length integer)
    
    Args:
        value: Integer to encode
        
    Returns:
        bytes: Varint-encoded bytes
    """
    result = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        if value:
            byte |= 0x80
        result.append(byte)
        if not value:
            break
    return bytes(result)


def _create_varint_field(field_number, value):
    """
    Create a varint field (wire type 0)
    
    Args:
        field_number: Field number
        value: Integer value
        
    Returns:
        bytes: Encoded field
    """
    tag = (field_number << 3) | 0  # Wire type 0 (varint)
    return _encode_varint(tag) + _encode_varint(int(value))


def _to_bytes(val):
    """
    Convert value to bytes
    
    Args:
        val: Value to convert (bytes, str, dict, etc.)
        
    Returns:
        bytes: Converted bytes
    """
    if isinstance(val, (bytes, bytearray)):
        return bytes(val)
    if isinstance(val, str):
        try:
            # Try unicode escape decoding first
            s = codecs.decode(val, "unicode_escape")
            return s.encode("latin-1", "replace")
        except Exception:
            return val.encode("utf-8", "replace")
    if isinstance(val, dict):
        return create_protobuf(val)
    return str(val).encode()


def _create_length_delimited_field(field_number, value):
    """
    Create a length-delimited field (wire type 2)
    
    Args:
        field_number: Field number
        value: Value to encode (bytes, str, or dict for nested messages)
        
    Returns:
        bytes: Encoded field
    """
    tag = (field_number << 3) | 2  # Wire type 2 (length-delimited)
    
    if isinstance(value, dict):
        # Nested message
        encoded_value = create_protobuf(value)
    else:
        encoded_value = _to_bytes(value)
    
    length = _encode_varint(len(encoded_value))
    return _encode_varint(tag) + length + encoded_value


def create_protobuf(fields):
    """
    Create a protobuf message from a field dictionary
    
    Args:
        fields: Dictionary mapping field numbers (as strings) to field data
                Format: {"field_num": {"wire_type": "...", "data": ...}}
                or simplified: {"field_num": value}
        
    Returns:
        bytes: Serialized protobuf message
    """
    if isinstance(fields, str):
        fields = json.loads(fields)
    
    packet = bytearray()
    
    for key, entry in fields.items():
        field_num = int(key)
        
        if isinstance(entry, dict) and "wire_type" in entry:
            # Structured format with wire_type
            wire_type = entry.get("wire_type")
            val = entry.get("data")
            
            if wire_type == "varint":
                packet.extend(_create_varint_field(field_num, int(val)))
            elif wire_type in ("string", "bytes"):
                packet.extend(_create_length_delimited_field(field_num, val))
            elif wire_type == "length_delimited":
                if isinstance(val, dict):
                    nested = create_protobuf(val)
                else:
                    nested = _to_bytes(val)
                packet.extend(_create_length_delimited_field(field_num, nested))
            else:
                # Fallback: try to infer type
                if isinstance(val, int):
                    packet.extend(_create_varint_field(field_num, val))
                elif isinstance(val, dict):
                    packet.extend(_create_length_delimited_field(field_num, create_protobuf(val)))
                else:
                    packet.extend(_create_length_delimited_field(field_num, val))
        else:
            # Simplified format: just value
            if isinstance(entry, int):
                packet.extend(_create_varint_field(field_num, entry))
            elif isinstance(entry, dict):
                packet.extend(_create_length_delimited_field(field_num, create_protobuf(entry)))
            else:
                packet.extend(_create_length_delimited_field(field_num, entry))
    
    return bytes(packet)


def parse_results(parsed_results):
    """
    Parse protobuf decoder results into a structured dictionary
    
    Args:
        parsed_results: Results from protobuf_decoder.Parser().parse()
        
    Returns:
        dict: Dictionary mapping field numbers to field data
    """
    result_dict = {}
    for result in parsed_results:
        field_data = {
            'wire_type': result.wire_type
        }
        
        if result.wire_type == "varint":
            field_data['data'] = result.data
        elif result.wire_type == "string":
            field_data['data'] = result.data
        elif result.wire_type == "bytes":
            field_data['data'] = result.data
        elif result.wire_type == 'length_delimited':
            field_data["data"] = parse_results(result.data.results)
        
        result_dict[str(result.field)] = field_data
    
    return result_dict


def parse_protobuf(protobuf_bytes):
    """
    Parse protobuf bytes into a field dictionary using generic decoder
    
    Args:
        protobuf_bytes: Bytes or hex string of protobuf message
        
    Returns:
        dict: Dictionary mapping field numbers to field data, or None on error
    """
    if not PROTOBUF_DECODER_AVAILABLE:
        raise ImportError("protobuf_decoder is required. Install with: pip install protobuf-decoder")
    
    try:
        if isinstance(protobuf_bytes, str):
            # Assume hex string
            protobuf_bytes = bytes.fromhex(protobuf_bytes)
        
        # Parse using generic decoder
        parsed_results = Parser().parse(protobuf_bytes)
        parsed_dict = parse_results(parsed_results)
        
        return parsed_dict
    except Exception as e:
        print(f"[ERROR] Failed to parse protobuf: {e}")
        return None


def protobuf_to_json(protobuf_bytes):
    """
    Convert protobuf bytes to JSON string
    
    Args:
        protobuf_bytes: Bytes or hex string of protobuf message
        
    Returns:
        str: JSON string representation, or None on error
    """
    parsed_dict = parse_protobuf(protobuf_bytes)
    if parsed_dict:
        return json.dumps(parsed_dict)
    return None


# Compatibility functions matching safe bypass exactly
def get_available_room(input_text):
    """
    Compatibility function matching safe bypass
    Takes hex string and returns JSON string of parsed protobuf
    
    Args:
        input_text: Hex string of protobuf bytes (or bytes that will be converted to hex)
        
    Returns:
        str: JSON string of parsed protobuf fields, or None on error
    """
    if not PROTOBUF_DECODER_AVAILABLE:
        print("[ERROR] get_available_room failed: protobuf_decoder not available. Install with: pip install protobuf-decoder")
        return None
    
    try:
        # Parser().parse() expects a hex string, not bytes!
        # If input is bytes, convert to hex string
        if isinstance(input_text, bytes):
            hex_string = input_text.hex()
        elif isinstance(input_text, str):
            # Already a hex string - pass directly
            hex_string = input_text
        else:
            # Try to convert to hex string
            hex_string = bytes(input_text).hex()
        
        # Parser().parse() expects hex string (matching safe bypass exactly)
        parsed_results = Parser().parse(hex_string)
        parsed_dict = parse_results(parsed_results)
        json_data = json.dumps(parsed_dict)
        return json_data
    except Exception as e:
        print(f"[ERROR] get_available_room failed: {e}")
        import traceback
        traceback.print_exc()
        return None


def CrEaTe_ProTo(fields):
    """
    Compatibility function matching safe bypass
    Creates protobuf from fields dictionary
    
    Args:
        fields: Dictionary or JSON string of field data
        
    Returns:
        bytes: Serialized protobuf message
    """
    return create_protobuf(fields)

