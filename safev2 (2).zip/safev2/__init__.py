"""
SafeV2 - Template-based protobuf bypass system
Provides safe protobuf modification using template preservation
"""

__version__ = "2.0.0"

