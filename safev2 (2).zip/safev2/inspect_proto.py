import sys
import os
import json

# Add safev2 directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from crypto.encryption_utils import aes_decrypt
    from protocols.protobuf_utils import get_available_room
except ImportError:
    print("Error importing modules. Make sure you are running this from safev2 directory.")
    sys.exit(1)

MOBILE_PROTO_HEX = (
    "aaf8a186a5c94b33453a39cc44d8fdef5971fedbd4ddafda01d8705a9c3628ff74c00856c47b11bba56d76991f6e3830d9288e0836d47287dbb3f8d9070889f5ceb65e357973cb498a77f5fda5d3e98821fc5ade51433944f9d78538b8c4236419d8a87f13ee462a1b19fc5962c6521fe56f926173f45f6f299a328d7dfee9c2949ecb4c50e2051427f49c3a65e8b9f1dc2dd8c8dddc8dc8c31793f3846b5832fb0ca1ed3c49bdbcbfcf1b6b828c4bb60d101fcc8e4a3dc78c12bbc06040ac295e1064e568a922f1c374d6d26a0c7d6bafd58b7c1cf3fc4fa0de004756805b927aa6c25a135dccfb58c2e3eef66b3e22a81882be9942cb89cb9511072fb98e7dc76fdfc834f825e09c1447481b4ba6e5c0357aaf93406f46cc342fc3871e8e799a7fa64802664411d6a520a3e024ee59b616fb6888e8971dc8c15e6e3d41139855a7e10d6feeb5a12d0855a00795d10a8c1a2d1396b99c49a5fb6151bdbeb3be7515a67947719c04e1b1aa4b7e77ab5cc465c3d3a1993fb35910b9ce5264fe84ad2fd30b47f9a0514568ce19e62e036921be2be52e22d4f65828248557d83b269f728a618c48a82829a38b4dac90ec71dcaa353ef94312be097a704664603d533feb7a37cf8b6cf87c7c9d0ec4d6f53246dafd025628dcdfcc05b34e6eda532be29dcdfb45c1ab2c8a26ce84859d5006aa06d4c2138a9b8a2a52ec08a2fe68022cae61cd5192d02c4560926c9ef6f6c1033c8136c4dd2daad77657a02a8d7e0383772a85d7cae1a7ae1b08d5cf90afb615e473c3f72ab6155e242692799ce1e54c5355a68f79cb30a1d6b2a4eb6876a3de2173297c461f0d13a09e9745efe996e0080e679a34e828fb0ef04da2a409c4dc4918f515b0eae02bde4e82276c757f7dadfabb649486085ca943cfcc0b7eb10c0df238c6613f6da2dea5a7d18b0817a690de4ebc8f15445a43687433128d657a86d47a6c296ed1a35a092b9a06fe8dc54ba3888e1afab2fa502d443536bc74028df5de33ec4140dea370aa45a5132a8fa33fc3ba2f986cc8578b4d4a2e0e5f4615334329f1f43da573efc8ee8e7d6fb47de991bd7b16b1818484f6d0e489e676acbaf62300ecb1ead8dbc15ed2cdfeb98e7533e1306d5c89a129030650ee86bf0398d651e7cc59b934b871535ef432e3571a52d9cfcbbecb7b180a09bce53063e5449f6b6393c09d7e175aae7c599190bf39ade583251c8922b582e8a91bf261e9d678cac4c4e9aadbaf19aef7ca09edbf79e7884a23b3702c3bc4e3227e2c"
)

def inspect_template():
    print("Decrypting template...")
    decrypted_bytes = aes_decrypt(MOBILE_PROTO_HEX)
    decrypted_hex = decrypted_bytes.hex()
    
    print("Parsing protobuf...")
    proto_json = get_available_room(decrypted_hex)
    
    if proto_json:
        data = json.loads(proto_json)
        print(json.dumps(data, indent=2))
        
        # Search for device related strings
        print("\n--- Potential Device Fields ---")
        for k, v in data.items():
            if isinstance(v, dict) and "data" in v:
                val = str(v["data"])
                # Heuristic for device names
                if any(x in val.lower() for x in ["samsung", "pixel", "oneplus", "xiaomi", "redmi", "iphone", "ipad", "android", "asus"]):
                    print(f"Field {k}: {val}")
    else:
        print("Failed to parse protobuf")

if __name__ == "__main__":
    inspect_template()
