"""
PROTO GRABBER - Capture MajorLogin Proto from Mobile Device
This script intercepts MajorLogin requests and saves the encrypted proto as a new template.
"""

import os
import sys
from mitmproxy import http
import json
import copy
from datetime import datetime

# Get the safev2 directory
SAFEV2_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(SAFEV2_DIR)

# Add directories to path
sys.path.insert(0, SAFEV2_DIR)
sys.path.insert(1, PARENT_DIR)

# Import crypto and protocols modules
try:
    from crypto.encryption_utils import aes_decrypt
    from protocols.protobuf_utils import get_available_room
    CRYPTO_AVAILABLE = True
    print("[proto_grabber] ✅ Crypto modules loaded successfully")
except ImportError:
    try:
        from safev2.crypto.encryption_utils import aes_decrypt
        from safev2.protocols.protobuf_utils import get_available_room
        CRYPTO_AVAILABLE = True
        print("[proto_grabber] ✅ Crypto modules loaded successfully (fallback path)")
    except ImportError:
        CRYPTO_AVAILABLE = False
        print("[proto_grabber] ❌ Crypto modules not available!")
        print("[proto_grabber] Please ensure crypto/ and protocols/ directories exist")

# Global variables to store captured data
captured_requests = []
output_dir = os.path.join(SAFEV2_DIR, "captured_protos")

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

def request(flow: http.HTTPFlow) -> None:
    """Intercept and capture MajorLogin requests"""
    
    if flow.request.method.upper() == "POST" and "/MajorLogin" in flow.request.path:
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            print("\n" + "=" * 80)
            print(f"🎯 MAJORLOGIN REQUEST CAPTURED! [{timestamp}]")
            print("=" * 80)
            
            # Get request data
            request_bytes = flow.request.content
            request_hex = request_bytes.hex()
            
            # Basic info
            print(f"📊 Request Info:")
            print(f"   Host: {flow.request.host}")
            print(f"   Path: {flow.request.path}")
            print(f"   Size: {len(request_bytes)} bytes")
            print(f"   Encrypted Hex Length: {len(request_hex)} chars")
            
            # Detect region
            is_india = "ind.freefire" in flow.request.host or "IND" in flow.request.path.upper()
            region = "INDIA" if is_india else "GLOBAL"
            print(f"   Region: {region}")
            
            # Save encrypted proto (this is what goes into MOBILE_PROTO)
            encrypted_filename = f"encrypted_proto_{region.lower()}_{timestamp}.txt"
            encrypted_path = os.path.join(output_dir, encrypted_filename)
            with open(encrypted_path, 'w') as f:
                f.write(request_hex)
            print(f"\n💾 Encrypted proto saved to: {encrypted_filename}")
            
            # Try to decrypt and analyze if crypto available
            if CRYPTO_AVAILABLE:
                try:
                    # Decrypt
                    decrypted_bytes = aes_decrypt(request_hex)
                    decrypted_hex = decrypted_bytes.hex()
                    
                    print(f"🔓 Decryption successful!")
                    print(f"   Decrypted size: {len(decrypted_bytes)} bytes")
                    
                    # Save decrypted proto
                    decrypted_filename = f"decrypted_proto_{region.lower()}_{timestamp}.hex"
                    decrypted_path = os.path.join(output_dir, decrypted_filename)
                    with open(decrypted_path, 'w') as f:
                        f.write(decrypted_hex)
                    print(f"💾 Decrypted proto saved to: {decrypted_filename}")
                    
                    # Try to parse protobuf structure
                    try:
                        proto_json = get_available_room(decrypted_hex)
                        if proto_json:
                            proto_fields = json.loads(proto_json)
                            
                            # Save parsed structure
                            json_filename = f"proto_structure_{region.lower()}_{timestamp}.json"
                            json_path = os.path.join(output_dir, json_filename)
                            with open(json_path, 'w', indent=2) as f:
                                json.dump(proto_fields, f, indent=2)
                            print(f"💾 Proto structure saved to: {json_filename}")
                            
                            # Display key fields
                            print(f"\n📋 Proto Structure Analysis:")
                            print(f"   Total fields: {len(proto_fields)}")
                            
                            # Extract important fields
                            uid = None
                            access_token = None
                            open_id = None
                            client_version = None
                            some_flag = None
                            
                            # Try to find UID in fields 1, 2, 3
                            for field_num in ["1", "2", "3"]:
                                if field_num in proto_fields and isinstance(proto_fields[field_num], dict):
                                    if "data" in proto_fields[field_num]:
                                        potential_uid = str(proto_fields[field_num]["data"])
                                        if potential_uid.isdigit() and len(potential_uid) > 5:
                                            uid = potential_uid
                                            print(f"   Field {field_num} (UID): {uid}")
                                            break
                            
                            # Access token (field 29)
                            if "29" in proto_fields and isinstance(proto_fields["29"], dict):
                                if "data" in proto_fields["29"]:
                                    access_token = str(proto_fields["29"]["data"])
                                    print(f"   Field 29 (Access Token): {access_token[:20]}..." if len(access_token) > 20 else f"   Field 29 (Access Token): {access_token}")
                            
                            # Open ID (field 22)
                            if "22" in proto_fields and isinstance(proto_fields["22"], dict):
                                if "data" in proto_fields["22"]:
                                    open_id = str(proto_fields["22"]["data"])
                                    print(f"   Field 22 (Open ID): {open_id}")
                            
                            # Client version (field 7)
                            if "7" in proto_fields and isinstance(proto_fields["7"], dict):
                                if "data" in proto_fields["7"]:
                                    client_version = str(proto_fields["7"]["data"])
                                    print(f"   Field 7 (Client Version): {client_version}")
                            
                            # Some flag (field 5) - important for bypass
                            if "5" in proto_fields and isinstance(proto_fields["5"], dict):
                                if "data" in proto_fields["5"]:
                                    some_flag = proto_fields["5"]["data"]
                                    print(f"   Field 5 (some_flag): {some_flag}")
                            
                            # Main active platform (fields 99, 100)
                            if "99" in proto_fields and isinstance(proto_fields["99"], dict):
                                if "data" in proto_fields["99"]:
                                    print(f"   Field 99 (Platform): {proto_fields['99']['data']}")
                            
                            if "100" in proto_fields and isinstance(proto_fields["100"], dict):
                                if "data" in proto_fields["100"]:
                                    print(f"   Field 100 (Platform): {proto_fields['100']['data']}")
                            
                            # Store capture info
                            capture_info = {
                                "timestamp": timestamp,
                                "region": region,
                                "host": flow.request.host,
                                "path": flow.request.path,
                                "encrypted_hex": request_hex,
                                "encrypted_file": encrypted_filename,
                                "decrypted_file": decrypted_filename,
                                "structure_file": json_filename,
                                "uid": uid,
                                "access_token": access_token,
                                "open_id": open_id,
                                "client_version": client_version,
                                "some_flag": some_flag,
                                "field_count": len(proto_fields)
                            }
                            captured_requests.append(capture_info)
                            
                            # Save capture info
                            info_filename = f"capture_info_{region.lower()}_{timestamp}.json"
                            info_path = os.path.join(output_dir, info_filename)
                            with open(info_path, 'w', indent=2) as f:
                                json.dump(capture_info, f, indent=2)
                            print(f"💾 Capture info saved to: {info_filename}")
                            
                            print(f"\n✅ CAPTURE COMPLETE!")
                            print(f"\n📝 To use this as a new template:")
                            print(f"   1. Copy the content from: {encrypted_filename}")
                            print(f"   2. Replace the MOBILE_PROTO variable in raw_bypass.py")
                            print(f"   3. The template will automatically load on next run")
                            
                    except Exception as e:
                        print(f"⚠️  Could not parse protobuf structure: {e}")
                        print(f"   (Proto still saved as encrypted hex)")
                        
                except Exception as e:
                    print(f"⚠️  Could not decrypt proto: {e}")
                    print(f"   (Proto still saved as encrypted hex)")
            else:
                print(f"\n⚠️  Crypto modules not available - proto saved as encrypted hex only")
            
            # Save a summary file
            summary_filename = "capture_summary.txt"
            summary_path = os.path.join(output_dir, summary_filename)
            with open(summary_path, 'a') as f:
                f.write(f"\n{'=' * 80}\n")
                f.write(f"Capture: {timestamp} | Region: {region} | Size: {len(request_bytes)} bytes\n")
                f.write(f"Files: {encrypted_filename}\n")
                f.write(f"{'=' * 80}\n")
            
            print("=" * 80)
            print()
            
        except Exception as e:
            print(f"\n❌ Error capturing request: {e}")
            import traceback
            traceback.print_exc()

def response(flow: http.HTTPFlow) -> None:
    """Response handler - just monitoring"""
    if "/MajorLogin" in flow.request.path:
        print(f"📥 MajorLogin response received: {flow.response.status_code}")

def done():
    """Called when mitmproxy shuts down"""
    print("\n" + "=" * 80)
    print("📊 PROTO GRABBER SESSION SUMMARY")
    print("=" * 80)
    print(f"Total requests captured: {len(captured_requests)}")
    
    if captured_requests:
        print(f"\nCaptures:")
        for i, capture in enumerate(captured_requests, 1):
            print(f"\n{i}. {capture['timestamp']} - {capture['region']}")
            print(f"   Files: {capture['encrypted_file']}")
            if capture.get('client_version'):
                print(f"   Version: {capture['client_version']}")
            if capture.get('some_flag') is not None:
                print(f"   some_flag: {capture['some_flag']}")
    
    print(f"\n📁 All files saved to: {output_dir}")
    print("=" * 80)

# Main execution
if __name__ == "__main__":
    import subprocess
    
    port = 24692
    
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print("Invalid port. Using default 24692.")
    
    print("\n" + "=" * 80)
    print("🎯 PROTO GRABBER - MajorLogin Proto Capture Tool")
    print("=" * 80)
    print(f"📡 Port: {port}")
    print(f"📁 Output Directory: {output_dir}")
    print()
    print("📱 SETUP INSTRUCTIONS:")
    print("   1. Configure your mobile device to use this proxy")
    print(f"      - Proxy IP: Your computer's IP address")
    print(f"      - Proxy Port: {port}")
    print("   2. Install mitmproxy certificate on your device")
    print("      - Visit http://mitm.it on your device")
    print("      - Download and install the certificate")
    print("   3. Open Free Fire and login")
    print("   4. The proto will be captured automatically!")
    print()
    print("⏳ Waiting for connections...")
    print("=" * 80)
    print()
    
    try:
        # Try to run mitmdump
        mitmdump_cmd = ["mitmdump", "-s", __file__, "-p", str(port), "--set", "block_global=false"]
        
        try:
            subprocess.run(mitmdump_cmd, check=True)
        except FileNotFoundError:
            # Try as Python module
            print("Trying alternative method...")
            from mitmproxy.tools import main
            sys.argv = ["mitmdump", "-s", __file__, "-p", str(port), "--set", "block_global=false"]
            main.mitmdump()
            
    except KeyboardInterrupt:
        print("\n🛑 Proto grabber stopped.")
    except Exception as e:
        print(f"❌ Error: {e}")
        print(f"\n💡 Try running manually:")
        print(f"   mitmdump -s {__file__} -p {port} --set block_global=false")

print("[proto_grabber] 🎯 Proto Grabber script loaded!")
print("[proto_grabber] Ready to capture MajorLogin requests...")
